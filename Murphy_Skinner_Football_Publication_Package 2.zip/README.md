# Murphy Skinner — Patterson High School Football Archive

Public historical profile for Murphy Skinner, Patterson High School No. 26, wide receiver and defensive back, varsity seasons 2002–2004.

## Verified highlights

- Three-time First-Team All-District selection: 2002, 2003 and 2004
- Three-time First-Team All-St. Mary Parish selection: 2002, 2003 and 2004
- Second-Team Big School All-Acadiana in 2002
- Member of Patterson's 2002 Louisiana Class 3A state runner-up team
- 99-yard touchdown reception in his first varsity start
- 2004 St. Mary Parish–Iberia Parish All-Star selection

## Documented receiving production so far

At least **71 receptions, 1,324 yards and 15 touchdowns** are supported by currently located records. These are minimum documented figures, not final career totals, because several games remain missing.

## Public website

https://murphyskinner357-blip.github.io/Murphy-Skinner-Football/

The archive is updated as additional newspaper records are located and verified.
